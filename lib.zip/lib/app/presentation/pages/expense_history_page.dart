import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:misgastosapp/app/presentation/controllers/expense_controller.dart';
import 'package:misgastosapp/app/presentation/controllers/income_controller.dart';
import 'package:misgastosapp/app/presentation/controllers/theme_controller.dart';
import 'package:misgastosapp/app/data/models/expense_model.dart';
import 'package:misgastosapp/app/data/models/income_model.dart';

class ExpenseHistoryPage extends StatelessWidget {
  final bool modoSoloLectura;
  const ExpenseHistoryPage({super.key, this.modoSoloLectura = false});

  @override
  Widget build(BuildContext context) {
    final expenseCtrl = Get.find<ExpenseController>();
    final incomeCtrl = Get.find<IncomeController>();

    return Scaffold(
      appBar: AppBar(title: const Text('Historial de movimientos')),
      drawer: Drawer(
        child: Column(
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.transparent),
              margin: EdgeInsets.zero,
              padding: EdgeInsets.zero,
              child: Container(
                alignment: Alignment.center,
                constraints: const BoxConstraints.expand(height: 160),
                child: Builder(
                  builder: (context) {
                    final isDark =
                        Theme.of(context).brightness == Brightness.dark;
                    final logoPath = isDark
                        ? 'assets/img/logo_misgastos_dark.png'
                        : 'assets/img/logo_misgastos.png';
                    return Image.asset(
                      logoPath,
                      width: 540,
                      height: 540,
                      fit: BoxFit.contain,
                    );
                  },
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Inicio'),
              onTap: () {
                Navigator.pop(context);
                Get.offAllNamed(
                  '/home',
                ); // Asegúrate de tener esta ruta en AppRoutes
              },
            ),
            Obx(() {
              final themeCtrl = Get.find<ThemeController>();
              return SwitchListTile(
                title: const Text('Modo oscuro'),
                value: themeCtrl.isDark,
                onChanged: (_) => themeCtrl.toggleTheme(),
                secondary: const Icon(Icons.brightness_6),
              );
            }),
          ],
        ),
      ),
      body: Obx(() {
        final gastos = expenseCtrl.expenses;
        final ingresos = incomeCtrl.incomes;

        final movimientos = [
          ...gastos.map((e) => {'tipo': 'gasto', 'obj': e}),
          ...ingresos.map((e) => {'tipo': 'ingreso', 'obj': e}),
        ];

        movimientos.sort((a, b) {
          final dateA = a['tipo'] == 'gasto'
              ? (a['obj'] as ExpenseModel).fecha
              : (a['obj'] as IncomeModel).fechaInicio!;
          final dateB = b['tipo'] == 'gasto'
              ? (b['obj'] as ExpenseModel).fecha
              : (b['obj'] as IncomeModel).fechaInicio!;
          return dateB.compareTo(dateA);
        });

        return ListView.builder(
          itemCount: movimientos.length,
          itemBuilder: (context, index) {
            final mov = movimientos[index];
            final tipo = mov['tipo'];

            if (tipo == 'gasto') {
              final gasto = mov['obj'] as ExpenseModel;
              return ListTile(
                leading: const Icon(Icons.arrow_downward, color: Colors.red),
                title: Text(gasto.descripcion),
                subtitle: Text(gasto.fecha.toLocal().toString().split(' ')[0]),
                trailing: Text('-\$${gasto.monto.toStringAsFixed(2)}'),
              );
            } else {
              final ingreso = mov['obj'] as IncomeModel;
              return ListTile(
                leading: const Icon(Icons.arrow_upward, color: Colors.green),
                title: Text(ingreso.descripcion),
                subtitle: Text(
                  ingreso.fechaInicio!.toLocal().toString().split(' ')[0],
                ),
                trailing: Text('+\$${ingreso.monto.toStringAsFixed(2)}'),
              );
            }
          },
        );
      }),
    );
  }
}
